package com.example.broadcast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Example_broadcast BC = new Example_broadcast();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter IFilter = new IntentFilter();
        IFilter.addAction("TestBroadcast");
        registerReceiver(BC, IFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(BC);
    }

    public void onClickShowBroadcast(View v){
        EditText Ed = (EditText) findViewById(R.id.textview);
        Intent intent = new Intent();
        intent.putExtra("Message" , (CharSequence) Ed.getText().toString());
        intent.setAction("TestBroadcast");
        sendBroadcast(intent);
    }
}