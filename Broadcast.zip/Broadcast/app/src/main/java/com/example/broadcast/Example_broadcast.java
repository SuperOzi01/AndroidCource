package com.example.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class Example_broadcast extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if("TestBroadcast".equals(intent.getAction())){
            String Recieved_BC = intent.getStringExtra("Message");
            Toast.makeText(context,Recieved_BC,Toast.LENGTH_LONG).show();
        }
    }
}
