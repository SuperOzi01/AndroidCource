package com.example.sqlliteexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telecom.Call;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    private EditText username, location, destination;
    private Button save;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.txtName);
        location = (EditText) findViewById(R.id.txtLocation);
        destination = (EditText) findViewById(R.id.txtDesignation);
        save = (Button) findViewById(R.id.btnSave);
        save.setOnClickListener(v -> {
            String name = username.getText().toString();
            String loc = location.getText().toString();
            String dest = destination.getText().toString();
            DbHandler mydb = new DbHandler(MainActivity.this);
            mydb.insert_db(name,loc,dest);
            intent = new Intent(MainActivity.this , DetailsActivity.class);
            startActivity(intent);
            Toast.makeText(this,"Saved Successfully" , Toast.LENGTH_LONG).show();
        });
    }
}