package com.example.sqlliteexample;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashMap;

public class DbHandler extends SQLiteOpenHelper{

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "usersdb";
    private static final String TABLE_Users = "userdetails";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_LOC = "location";
    private static final String KEY_DESG = "designation";

    public DbHandler(Context context){
        super(context,DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_Users + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_LOC + " TEXT,"
                + KEY_DESG + " TEXT"
                + ")";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Users);
        // Create tables again
        onCreate(db);
    }


    void insert_db(String name, String location, String des){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cValues = new ContentValues();
        cValues.put(KEY_NAME , name);
        cValues.put(KEY_LOC,location);
        cValues.put(KEY_DESG,des);

        db.insert(TABLE_Users,null,cValues);
        db.close();
    }

    public ArrayList<HashMap<String,String>> GetUsers(){
        ArrayList<HashMap<String,String>> list = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " +KEY_NAME+","+ KEY_LOC + "," + KEY_DESG + " FROM " + TABLE_Users ;
        Cursor cursor = db.rawQuery(query,null);

        while(cursor.moveToNext()){
            HashMap<String , String> user = new HashMap<>();
            user.put(KEY_NAME , cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            user.put(KEY_LOC , cursor.getString(cursor.getColumnIndex(KEY_LOC)));
            user.put(KEY_DESG,cursor.getString(cursor.getColumnIndex(KEY_DESG)));
            list.add(user);
        }
        db.close();
        return list;
    }


}
